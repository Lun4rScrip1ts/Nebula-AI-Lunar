@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Nebula AI - Lunar Installer

echo.
echo  Nebula AI - Lunar 0.6.0 - Setup
 echo =========================
echo This will install dependencies, prepare Electron, build the installer,
echo and open the Windows setup wizard. You only need to do this once.
echo.

where node.exe >nul 2>&1
if errorlevel 1 (
  echo ERROR: Node.js was not found.
  echo Install Node.js 22 or newer from https://nodejs.org/ and run this file again.
  pause
  exit /b 1
)

if not exist package.json (
  echo ERROR: package.json was not found. Extract this ZIP fully and run this file from its folder.
  pause
  exit /b 1
)

echo [1/5] Installing project packages...
call npm.cmd install
if errorlevel 1 goto failed

echo [2/5] Approving Electron's install script...
call npm.cmd install-scripts approve electron

echo [3/5] Preparing Electron runtime...
node .\node_modules\electron\install.js
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\tools\repair-electron.ps1"
if errorlevel 1 goto failed

echo [4/5] Building the Windows installer...
call npm.cmd run dist
if errorlevel 1 goto failed

set "SETUP=%CD%\release\Nebula-AI-Lunar-Setup-0.6.0.exe"
if not exist "%SETUP%" (
  echo ERROR: The build finished but the expected installer was not found.
  echo Check the release folder for the generated EXE.
  pause
  exit /b 1
)

echo [5/5] Opening the Windows installer...
start /wait "Nebula AI - Lunar Setup" "%SETUP%"
echo.
echo Setup wizard closed. Look for Nebula AI - Lunar in the Start Menu or on your desktop.
echo You can close this window now.
pause
exit /b 0

:failed
echo.
echo INSTALLATION DID NOT FINISH.
echo Please take a screenshot of the error above and send it in ChatGPT.
pause
exit /b 1
