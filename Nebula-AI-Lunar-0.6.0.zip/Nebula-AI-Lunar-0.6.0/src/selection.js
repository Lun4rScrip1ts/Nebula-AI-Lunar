const image = document.getElementById('screenImage')
const selection = document.getElementById('selection')
const useButton = document.getElementById('useCapture')
let start = null
let rect = null
let screenData = null
let finished = false

window.glassAI.onCaptureImage(dataUrl => {
  screenData = dataUrl
  image.src = dataUrl
})

function setRect(x1, y1, x2, y2) {
  const left = Math.max(0, Math.min(x1, x2))
  const top = Math.max(0, Math.min(y1, y2))
  const right = Math.min(window.innerWidth, Math.max(x1, x2))
  const bottom = Math.min(window.innerHeight, Math.max(y1, y2))
  rect = { left, top, width: right - left, height: bottom - top }
  selection.style.display = 'block'
  selection.style.left = `${left}px`
  selection.style.top = `${top}px`
  selection.style.width = `${rect.width}px`
  selection.style.height = `${rect.height}px`
  useButton.disabled = rect.width < 12 || rect.height < 12
}

document.addEventListener('pointerdown', event => {
  if (event.button !== 0 || event.target.closest('#toolbar')) return
  start = { x: event.clientX, y: event.clientY }
  setRect(start.x, start.y, start.x, start.y)
})
document.addEventListener('pointermove', event => {
  if (start) setRect(start.x, start.y, event.clientX, event.clientY)
})
document.addEventListener('pointerup', event => {
  if (!start) return
  setRect(start.x, start.y, event.clientX, event.clientY)
  start = null
})

function confirmCapture() {
  if (finished || !rect || !screenData || rect.width < 12 || rect.height < 12) return
  finished = true
  const source = new Image()
  source.onload = () => {
    const scaleX = source.naturalWidth / window.innerWidth
    const scaleY = source.naturalHeight / window.innerHeight
    const canvas = document.createElement('canvas')
    canvas.width = Math.max(1, Math.round(rect.width * scaleX))
    canvas.height = Math.max(1, Math.round(rect.height * scaleY))
    const context = canvas.getContext('2d')
    context.drawImage(source, Math.round(rect.left * scaleX), Math.round(rect.top * scaleY), canvas.width, canvas.height, 0, 0, canvas.width, canvas.height)
    window.glassAI.captureFinished(canvas.toDataURL('image/jpeg', 0.9))
  }
  source.onerror = () => window.glassAI.captureCancel()
  source.src = screenData
}

function cancelCapture() {
  if (finished) return
  finished = true
  window.glassAI.captureCancel()
}

useButton.addEventListener('click', confirmCapture)
document.getElementById('cancel').addEventListener('click', cancelCapture)
document.addEventListener('keydown', event => {
  if (event.key === 'Escape') {
    event.preventDefault()
    cancelCapture()
  } else if (event.key === 'Enter') {
    event.preventDefault()
    confirmCapture()
  }
})
window.addEventListener('blur', () => {})
