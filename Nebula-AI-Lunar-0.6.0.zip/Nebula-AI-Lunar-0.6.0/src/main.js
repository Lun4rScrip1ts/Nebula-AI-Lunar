const { app, BrowserWindow, ipcMain, globalShortcut, screen, desktopCapturer, Tray, Menu, nativeImage, shell, safeStorage, clipboard, dialog } = require('electron')
const path = require('node:path')
const fs = require('node:fs')
const http = require('node:http')
const crypto = require('node:crypto')
const { spawn } = require('node:child_process')
const { jwtVerify, createRemoteJWKSet } = require('jose')

const APP_NAME = 'Nebula AI - Lunar'
const ISSUER = 'https://auth.openai.com'
const TOKEN_URL = 'https://auth.openai.com/api/accounts/oauth/token'
const AUTH_URL = 'https://auth.openai.com/api/accounts/authorize'
const RESOURCE = 'https://api.openai.com/v1'
const JWKS = createRemoteJWKSet(new URL('https://auth.openai.com/.well-known/jwks.json'))

let mainWindow
let selectionWindow
let tray
let authServer
let pendingCapture = null
let hostId
let credentials = null
let lastModel = null

const userDir = app.getPath('userData')
const authPath = path.join(userDir, 'connection.dat')
const apiKeyPath = path.join(userDir, 'image-api-key.dat')
const hostPath = path.join(userDir, 'host-id.txt')
const historyPath = path.join(userDir, 'history.json')
const privacyPath = path.join(userDir, 'screen-privacy.json')
const blurPath = path.join(userDir, 'blur-setting.json')
let blurAmount = 0
let screenPrivacyEnabled = false

function readHostId() {
  try {
    const saved = fs.readFileSync(hostPath, 'utf8').trim()
    if (saved) return saved
  } catch {}

  const id = `urn:uuid:${crypto.randomUUID()}`
  fs.mkdirSync(userDir, { recursive: true })
  fs.writeFileSync(hostPath, id, 'utf8')
  return id
}

function loadCredentials() {
  try {
    if (!safeStorage.isEncryptionAvailable()) return null
    const encrypted = fs.readFileSync(authPath)
    return JSON.parse(safeStorage.decryptString(encrypted))
  } catch {
    return null
  }
}

function saveCredentials(value) {
  if (!safeStorage.isEncryptionAvailable()) {
    throw new Error('Windows credential encryption is unavailable. Restart Windows or check your user session.')
  }

  fs.mkdirSync(userDir, { recursive: true })
  fs.writeFileSync(authPath, safeStorage.encryptString(JSON.stringify(value)))
  credentials = value
}

function clearCredentials() {
  credentials = null
  try {
    fs.unlinkSync(authPath)
  } catch {}
}

function loadScreenPrivacy() {
  try {
    const data = JSON.parse(fs.readFileSync(privacyPath, 'utf8'))
    screenPrivacyEnabled = Boolean(data.enabled)
  } catch {
    screenPrivacyEnabled = false
  }
}

function applyScreenPrivacy(enabled) {
  screenPrivacyEnabled = Boolean(enabled)
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.setContentProtection(screenPrivacyEnabled)
  }
  fs.mkdirSync(userDir, { recursive: true })
  fs.writeFileSync(privacyPath, JSON.stringify({ enabled: screenPrivacyEnabled }, null, 2), 'utf8')
  return { enabled: screenPrivacyEnabled }
}

function createMainWindow() {
  const display = screen.getPrimaryDisplay()
  const width = 850

  mainWindow = new BrowserWindow({
    title: '',
    width,
    height: 88,
    x: Math.round(display.workArea.x + (display.workArea.width - width) / 2),
    y: display.workArea.y + 20,
    show: false,
    frame: false,
    transparent: true,
    backgroundColor: '#00000000',
    backgroundMaterial: process.platform === 'win32' && blurAmount > 0 ? 'acrylic' : 'none',
    resizable: true,
    minWidth: 560,
    minHeight: 88,
    minimizable: false,
    maximizable: false,
    skipTaskbar: true,
    alwaysOnTop: true,
    hasShadow: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  })

  mainWindow.on('page-title-updated', event => {
    event.preventDefault()
    if (!mainWindow.isDestroyed()) mainWindow.setTitle('')
  })

  mainWindow.setAlwaysOnTop(true, 'screen-saver')
  mainWindow.setContentProtection(screenPrivacyEnabled)

  let didShow = false
  const revealWindow = () => {
    if (didShow || !mainWindow || mainWindow.isDestroyed()) return
    didShow = true
    mainWindow.show()
    mainWindow.focus()
    mainWindow.setAlwaysOnTop(true, 'screen-saver')
  }

  mainWindow.once('ready-to-show', revealWindow)
  mainWindow.webContents.once('did-finish-load', revealWindow)
  setTimeout(revealWindow, 1800)

  mainWindow.webContents.on('did-fail-load', (_, code, description) => {
    console.error('Nebula AI - Lunar failed to load:', code, description)
  })

  mainWindow.webContents.on('render-process-gone', (_, details) => {
    console.error('Nebula AI - Lunar renderer stopped:', details.reason)
  })

  mainWindow.loadFile(path.join(__dirname, 'index.html'))
  mainWindow.setTitle('')

  mainWindow.on('closed', () => {
    mainWindow = null
  })

  mainWindow.on('blur', () => {
    setTimeout(() => {
      if (
        mainWindow &&
        !mainWindow.isDestroyed() &&
        !mainWindow.isFocused() &&
        !mainWindow.webContents.isDevToolsOpened()
      ) {
        mainWindow.webContents.send('overlay-blurred')
      }
    }, 250)
  })
}

function showMainWindow(focus = true) {
  if (!mainWindow) {
    createMainWindow()
    return
  }

  mainWindow.setAlwaysOnTop(true, 'screen-saver')
  mainWindow.show()

  if (focus) mainWindow.focus()

  if (!mainWindow.webContents.isLoading()) {
    mainWindow.webContents.send('overlay-opened')
  } else {
    mainWindow.webContents.once('did-finish-load', () => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('overlay-opened')
      }
    })
  }
}

function toggleMainWindow() {
  if (!mainWindow) {
    showMainWindow()
    return
  }

  if (mainWindow.isVisible()) {
    mainWindow.hide()
  } else {
    showMainWindow()
  }
}

function createTray() {
  const icon = nativeImage.createFromDataURL(
    'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAKElEQVQ4T2NkYGD4z0AEYBxVSFUBCjA0MDAw/GfABKQGBoYh0QwMDAwAAN8ABf1l4QwAAAAASUVORK5CYII='
  )

  tray = new Tray(icon)
  tray.setToolTip(APP_NAME)

  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Open Nebula AI - Lunar', click: () => showMainWindow() },
    { label: 'Capture screen area', click: () => startCapture() },
    { type: 'separator' },
    { label: 'Quit', click: () => app.quit() }
  ]))

  tray.on('double-click', () => showMainWindow())
}

function randomBase64Url(size = 32) {
  return crypto.randomBytes(size).toString('base64url')
}

function sha256Base64Url(value) {
  return crypto.createHash('sha256').update(value).digest('base64url')
}

function parseScopes(value) {
  return String(value || '').split(/\s+/).filter(Boolean)
}

async function signIn() {
  if (authServer) {
    throw new Error('A sign-in window is already waiting. Finish it in your browser first.')
  }

  const state = randomBase64Url()
  const nonce = randomBase64Url()
  const verifier = randomBase64Url(48)
  const challenge = sha256Base64Url(verifier)
  const server = http.createServer()

  authServer = server

  try {
    await new Promise((resolve, reject) => {
      server.once('error', reject)
      server.listen(0, '127.0.0.1', resolve)
    })

    const port = server.address().port
    const redirectUri = `http://127.0.0.1:${port}/auth/callback`

    const callbackPromise = new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('Sign-in timed out. Please try again.'))
      }, 5 * 60 * 1000)

      server.on('request', (req, res) => {
        const url = new URL(req.url, redirectUri)

        if (url.pathname !== '/auth/callback') {
          res.writeHead(404).end('Not found')
          return
        }

        if (url.searchParams.get('state') !== state) {
          res.writeHead(400, { 'content-type': 'text/html; charset=utf-8' })
            .end('<h2>Sign-in state did not match.</h2>You can close this tab.')
          clearTimeout(timeout)
          reject(new Error('Sign-in validation failed. Please try again.'))
          return
        }

        const error = url.searchParams.get('error')

        if (error) {
          res.writeHead(400, { 'content-type': 'text/html; charset=utf-8' })
            .end('<h2>Sign-in was not completed.</h2>You can close this tab and return to Nebula AI - Lunar.')
          clearTimeout(timeout)
          reject(new Error(`ChatGPT sign-in was not completed: ${error}`))
          return
        }

        const code = url.searchParams.get('code')
        const clientId = url.searchParams.get('client_id') || credentials?.clientId

        if (!code || !clientId) {
          res.writeHead(400, { 'content-type': 'text/html; charset=utf-8' })
            .end('<h2>Missing sign-in information.</h2>You can close this tab and try again.')
          clearTimeout(timeout)
          reject(new Error('The sign-in callback did not include the required information.'))
          return
        }

        res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
          .end('<!doctype html><html><body style="font:16px Segoe UI;background:#0b1020;color:#edf4ff;padding:40px"><h2>Nebula AI - Lunar connected</h2><p>You can close this browser tab and return to the app.</p></body></html>')

        clearTimeout(timeout)
        resolve({ code, clientId })
      })
    })

    const params = new URLSearchParams({
      client_id: credentials?.clientId || 'dynamic_agent_client',
      response_type: 'code',
      redirect_uri: redirectUri,
      scope: 'openid profile email offline_access resource.invoke chatgpt.tokens.use.direct',
      resource: RESOURCE,
      state,
      nonce,
      code_challenge: challenge,
      code_challenge_method: 'S256',
      ext_agent_host_id: hostId,
      ...(!credentials?.clientId ? { agent_name_hint: APP_NAME } : {})
    })

    await shell.openExternal(`${AUTH_URL}?${params.toString()}`)

    if (mainWindow) {
      mainWindow.webContents.send('status-message', 'Complete sign-in in your browser…')
    }

    const callback = await callbackPromise
    const body = new URLSearchParams({
      grant_type: 'authorization_code',
      client_id: callback.clientId,
      code: callback.code,
      code_verifier: verifier,
      redirect_uri: redirectUri,
      resource: RESOURCE
    })

    const tokenResponse = await fetch(TOKEN_URL, {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body
    })

    const tokenData = await tokenResponse.json()

    if (!tokenResponse.ok) {
      throw new Error(tokenData.error_description || tokenData.error || 'Token exchange failed.')
    }

    if (!tokenData.id_token || !tokenData.access_token) {
      throw new Error('ChatGPT did not return the required credentials.')
    }

    const { payload } = await jwtVerify(tokenData.id_token, JWKS, {
      issuer: ISSUER,
      audience: callback.clientId
    })

    if (payload.nonce !== nonce) {
      throw new Error('The sign-in nonce did not match. Please try again.')
    }

    const next = {
      clientId: callback.clientId,
      accessToken: tokenData.access_token,
      refreshToken: tokenData.refresh_token || credentials?.refreshToken || null,
      expiresAt: Date.now() + Number(tokenData.expires_in || 3600) * 1000,
      scope: parseScopes(tokenData.scope),
      account: {
        subject: payload.sub,
        email: payload.email || '',
        name: payload.name || 'Connected ChatGPT account'
      },
      idToken: tokenData.id_token
    }

    saveCredentials(next)
    return getStatus()
  } finally {
    await new Promise(resolve => {
      if (!authServer) return resolve()
      const serverToClose = authServer
      authServer = null
      serverToClose.close(() => resolve())
    })
  }
}

async function getAccessToken() {
  if (!credentials) {
    throw new Error('Connect your ChatGPT account first.')
  }

  if (credentials.expiresAt && Date.now() < credentials.expiresAt - 60000) {
    return credentials.accessToken
  }

  if (!credentials.refreshToken) {
    throw new Error('Your ChatGPT connection expired. Please reconnect your account.')
  }

  const body = new URLSearchParams({
    grant_type: 'refresh_token',
    client_id: credentials.clientId,
    refresh_token: credentials.refreshToken,
    resource: RESOURCE
  })

  const response = await fetch(TOKEN_URL, {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body
  })

  const data = await response.json()

  if (!response.ok) {
    clearCredentials()
    throw new Error('Your ChatGPT connection needs to be renewed. Please connect again.')
  }

  credentials = {
    ...credentials,
    accessToken: data.access_token,
    refreshToken: data.refresh_token || credentials.refreshToken,
    expiresAt: Date.now() + Number(data.expires_in || 3600) * 1000,
    scope: parseScopes(data.scope || (credentials.scope || []).join(' ')),
    idToken: data.id_token || credentials.idToken
  }

  saveCredentials(credentials)
  return credentials.accessToken
}

function getStatus() {
  if (!credentials) {
    return { connected: false, sharing: false, account: null }
  }

  const scopes = credentials.scope || []
  return {
    connected: true,
    sharing: scopes.includes('chatgpt.tokens.use.direct'),
    account: credentials.account || null
  }
}


function loadImageApiKey() {
  try {
    if (!safeStorage.isEncryptionAvailable()) return ''
    return safeStorage.decryptString(fs.readFileSync(apiKeyPath)).trim()
  } catch {
    return ''
  }
}

function saveImageApiKey(value) {
  const key = String(value || '').trim()
  if (!safeStorage.isEncryptionAvailable()) {
    throw new Error('Windows credential encryption is unavailable. Restart Windows or check your user session.')
  }
  if (key && !key.startsWith('sk-')) throw new Error('That does not look like an OpenAI API key.')
  fs.mkdirSync(userDir, { recursive: true })
  if (key) fs.writeFileSync(apiKeyPath, safeStorage.encryptString(key))
  else {
    try { fs.unlinkSync(apiKeyPath) } catch {}
  }
  return { configured: Boolean(key) }
}

async function generateImageWithApiKey(prompt, imageData, onProgress) {
  const apiKey = loadImageApiKey()
  if (!apiKey) throw new Error('Your ChatGPT sign-in cannot generate images. Add an OpenAI API key in Settings → Image generation. API usage is billed separately from ChatGPT.')
  onProgress({ type: 'status', text: 'Creating your image…' })
  const body = {
    model: 'gpt-image-1',
    prompt: String(prompt || 'Create an image based on the supplied reference image.'),
    size: '1024x1024',
    quality: 'high'
  }
  if (imageData) {
    throw new Error('Image editing from a screenshot is not available in this API-key image mode yet. Try generating a new image from a text description.')
  }
  const response = await fetch('https://api.openai.com/v1/images/generations', {
    method: 'POST',
    headers: { authorization: `Bearer ${apiKey}`, 'content-type': 'application/json' },
    body: JSON.stringify(body)
  })
  const data = await response.json().catch(() => ({}))
  if (!response.ok) throw new Error(data.error?.message || `Image generation failed with status ${response.status}. Check your API key and API billing.`)
  const encoded = data.data?.[0]?.b64_json
  if (!encoded) throw new Error('The image API returned no image data. Please try again.')
  onProgress({ type: 'status', text: 'Finishing your image…' })
  return { answer: '', model: 'gpt-image-1', imageData: `data:image/png;base64,${encoded}`, generatedImage: true }
}

function isImageRequest(prompt) {
  return /\b(generate|create|draw|paint|illustrate|render|make|turn|convert)\b.{0,90}\b(image|picture|illustration|artwork|wallpaper|logo|icon|poster|thumbnail|graphic|visual)\b/i.test(String(prompt || '')) ||
    /\b(make|turn|convert)\s+(this|that|it|the\s+svg)\s+(into|as)\s+(an?\s+)?(image|picture|png|jpg|jpeg)\b/i.test(String(prompt || ''))
}

async function askAI({ prompt, imageData, attachments = [], generateImage = false }, onProgress = () => {}) {
  const cleanPrompt = String(prompt || '').trim()
  const shouldGenerateImage = Boolean(generateImage) || isImageRequest(cleanPrompt)

  if (!cleanPrompt && !imageData && !attachments.length) {
    throw new Error('Type a question, upload a file, or capture part of your screen first.')
  }

  if (shouldGenerateImage) return generateImageWithApiKey(cleanPrompt, imageData, onProgress)

  if (!credentials) {
    throw new Error('Connect your ChatGPT account first.')
  }

  if (!getStatus().sharing) {
    throw new Error('ChatGPT plan usage is not enabled. Reconnect and approve the requested permission if available.')
  }

  const token = await getAccessToken()
  const modelsResponse = await fetch(`${RESOURCE}/models`, {
    headers: { authorization: `Bearer ${token}` }
  })
  const modelsData = await modelsResponse.json()

  if (!modelsResponse.ok) {
    throw new Error(modelsData.error?.message || 'Could not load available ChatGPT models.')
  }

  const models = (modelsData.models || []).filter(model => model.visibility === 'list' && model.slug)
  const model = models.find(item => /gpt/i.test(item.slug)) || models[0]

  if (!model) {
    throw new Error('No models were returned for this ChatGPT account. Check your connection and granted permissions.')
  }

  lastModel = model.slug

  const content = [{
    type: 'input_text',
    text: shouldGenerateImage
      ? `Create an actual finished image for this request. Do not return SVG, HTML, Markdown, or image-generation code. Use the image generation tool and return the generated image itself. User request: ${cleanPrompt}`
      : (cleanPrompt || 'Analyze this screenshot and explain how to solve the problem shown.')
  }]

  if (imageData) content.push({ type: 'input_image', image_url: imageData })
  for (const file of attachments) {
    if (!file || typeof file.data !== 'string' || !file.data.startsWith('data:')) continue
    if (String(file.type || '').startsWith('image/')) {
      content.push({ type: 'input_image', image_url: file.data })
    } else if (String(file.type || '') === 'application/pdf') {
      content.push({ type: 'input_file', filename: String(file.name || 'document.pdf'), file_data: file.data })
    } else if (typeof file.text === 'string' && file.text.length) {
      content[0].text += `\n\nAttached file: ${String(file.name || 'file')}\n---\n${file.text.slice(0, 90000)}\n---`
    }
  }

  const tools = shouldGenerateImage
    ? [{
        type: 'image_generation',
        model: 'gpt-image-2.5-sunburst',
        action: imageData ? 'auto' : 'generate',
        partial_images: 2
      }]
    : undefined

  const requestBody = {
    model: model.slug,
    input: [
      {
        role: 'system',
        content: [{
          type: 'input_text',
          text: shouldGenerateImage
            ? 'You are an image creation assistant. For image requests, use the image_generation tool to produce a complete raster image. Never substitute SVG or code for the image unless the user explicitly asks for source code. Keep any accompanying text brief.'
            : 'You are Nebula AI - Lunar, a capable and conversational desktop assistant. First give the direct answer or solution, then explain the key reasoning and steps in enough detail that the user can understand and apply it. For school-style problems, solve the actual problem rather than only giving hints; show calculations and check the result when useful. For troubleshooting, identify the likely cause and give practical steps in order. If text is selected from another app, interpret it as the material or question the user is asking about: answer any question in it, solve any problem in it, or explain the passage if it is not a question. Do not merely repeat or summarize selected text unless asked. Use clear standard Markdown, helpful examples when they improve understanding, and fenced code blocks with language labels for code. Avoid unnecessary disclaimers and avoid being overly terse, but do not pad the answer. For screenshots, describe only what is visible and say when something is uncertain.'
        }]
      },
      { role: 'user', content }
    ],
    store: false,
    stream: true
  }

  if (tools) {
    requestBody.tools = tools
    requestBody.tool_choice = 'required'
  }

  if (shouldGenerateImage) onProgress({ type: 'status', text: 'Creating your image…' })

  const response = await fetch(`${RESOURCE}/responses`, {
    method: 'POST',
    headers: {
      authorization: `Bearer ${token}`,
      'content-type': 'application/json'
    },
    body: JSON.stringify(requestBody)
  })

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}))
    const message = errorData.error?.message || `AI request failed with status ${response.status}.`
    if (shouldGenerateImage && [400, 403, 404, 422].includes(response.status)) {
      throw new Error(`Image generation is not available through this ChatGPT connection, or the image tool was rejected. Details: ${message}`)
    }
    throw new Error(message)
  }

  if (!response.body) throw new Error('The AI response stream was empty.')

  let answer = ''
  let generatedImage = null
  let buffer = ''

  const handleSseLine = line => {
    if (!line.startsWith('data: ')) return
    const value = line.slice(6).trim()
    if (!value || value === '[DONE]') return

    let event
    try { event = JSON.parse(value) } catch { return }

    if (event.type === 'response.output_text.delta') answer += event.delta || ''

    if (event.type === 'response.image_generation_call.in_progress' || event.type === 'response.image_generation_call.generating') {
      onProgress({ type: 'status', text: 'Rendering the image…' })
    }

    if (event.type === 'response.image_generation_call.partial_image' && event.partial_image_b64) {
      onProgress({ type: 'partial-image', dataUrl: `data:image/png;base64,${event.partial_image_b64}` })
    }

    if (event.type === 'response.completed') {
      const output = event.response?.output || []
      const imageCall = output.find(item => item.type === 'image_generation_call' && item.result)
      if (imageCall?.result) generatedImage = `data:image/png;base64,${imageCall.result}`
      if (!answer.trim() && event.response?.output_text) answer = event.response.output_text
    }

    if (event.type === 'response.failed' || event.type === 'error') {
      throw new Error(event.response?.error?.message || event.error?.message || 'The AI response failed.')
    }
  }

  for await (const chunk of response.body) {
    buffer += Buffer.from(chunk).toString('utf8')
    const lines = buffer.split(/\r?\n/)
    buffer = lines.pop() || ''
    for (const line of lines) handleSseLine(line)
  }
  if (buffer.trim()) handleSseLine(buffer.trim())

  if (shouldGenerateImage && !generatedImage) {
    if (!answer.trim()) {
      throw new Error('The connection finished without returning an image. Image generation may not be enabled for this ChatGPT connection.')
    }
    throw new Error(`The AI returned text instead of a generated image. Try again, or check whether image generation is supported by this connection. Response: ${answer.slice(0, 300)}`)
  }

  if (!answer.trim() && !generatedImage) throw new Error('The AI returned no text or image. Try again.')

  return { answer: answer.trim(), model: model.slug, imageData: generatedImage, generatedImage: Boolean(generatedImage) }
}

async function startCapture() {
  if (selectionWindow && !selectionWindow.isDestroyed()) {
    selectionWindow.focus()
    return
  }

  const display = screen.getPrimaryDisplay()
  const { width, height, x, y } = display.bounds

  try {
    if (mainWindow && !mainWindow.isDestroyed()) mainWindow.hide()
    await new Promise(resolve => setTimeout(resolve, 140))

    const sources = await desktopCapturer.getSources({
      types: ['screen'],
      thumbnailSize: {
        width: Math.max(1280, width),
        height: Math.max(720, height)
      }
    })

    const source = sources.find(item => item.display_id === String(display.id)) || sources[0]
    if (!source) throw new Error('Could not capture the screen.')

    pendingCapture = source.thumbnail.toDataURL()

    selectionWindow = new BrowserWindow({
      x, y, width, height,
      show: false,
      frame: false,
      transparent: false,
      backgroundColor: '#070b14',
      resizable: false,
      movable: false,
      skipTaskbar: true,
      alwaysOnTop: true,
      fullscreen: true,
      webPreferences: {
        preload: path.join(__dirname, 'preload.js'),
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: true
      }
    })

    selectionWindow.setAlwaysOnTop(true, 'screen-saver')
    selectionWindow.setContentProtection(screenPrivacyEnabled)
    selectionWindow.webContents.on('did-fail-load', (_, code, description) => {
      console.error('Screen selection failed to load:', code, description)
      if (selectionWindow && !selectionWindow.isDestroyed()) selectionWindow.close()
      showMainWindow()
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('status-message', 'Screen capture could not open. The capture window was closed safely.')
      }
    })

    selectionWindow.loadFile(path.join(__dirname, 'selection.html')).catch(error => {
      console.error('Could not load screen selection:', error)
      closeSelection()
      showMainWindow()
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('status-message', 'Screen capture files are missing or could not be loaded.')
      }
    })

    selectionWindow.once('ready-to-show', () => {
      if (!selectionWindow || selectionWindow.isDestroyed()) return
      selectionWindow.show()
      selectionWindow.webContents.send('capture-image', pendingCapture)
    })

    selectionWindow.on('closed', () => {
      selectionWindow = null
      pendingCapture = null
      if (mainWindow && !mainWindow.isDestroyed() && !mainWindow.isVisible()) showMainWindow()
    })
  } catch (error) {
    console.error('Screen capture failed:', error)
    showMainWindow()
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('status-message', error.message || 'Screen capture failed.')
    }
  }
}

function closeSelection() {
  if (selectionWindow && !selectionWindow.isDestroyed()) selectionWindow.close()
  selectionWindow = null
  pendingCapture = null
}

function readHistory() {
  try {
    return JSON.parse(fs.readFileSync(historyPath, 'utf8'))
  } catch {
    return []
  }
}

function writeHistory(items) {
  fs.mkdirSync(userDir, { recursive: true })
  fs.writeFileSync(historyPath, JSON.stringify(items.slice(-50), null, 2), 'utf8')
}

app.whenReady().then(() => {
  hostId = readHostId()
  credentials = loadCredentials()
  loadScreenPrivacy()
  try { blurAmount = Math.max(0, Math.min(60, Number(JSON.parse(fs.readFileSync(blurPath, 'utf8')).value) || 0)) } catch {}
  createMainWindow()
  createTray()
  globalShortcut.register('Alt+Space', toggleMainWindow)
  globalShortcut.register('Alt+Shift+A', startCapture)
}).catch(error => {
  console.error('Nebula AI - Lunar failed to start:', error)
  dialog.showErrorBox('Nebula AI - Lunar could not start', String(error && error.stack || error))
  app.quit()
})

app.on('activate', () => showMainWindow())
app.on('will-quit', () => { globalShortcut.unregisterAll() })
app.on('window-all-closed', event => event.preventDefault())

ipcMain.handle('copy-text', (_, value) => { clipboard.writeText(String(value ?? '')); return true })
ipcMain.handle('open-external', async (_, value) => {
  try {
    const url = new URL(String(value))
    if (url.protocol !== 'https:' && url.protocol !== 'http:') return false
    await shell.openExternal(url.href)
    return true
  } catch {
    return false
  }
})
ipcMain.handle('get-status', () => getStatus())
ipcMain.handle('get-image-api-key-status', () => ({ configured: Boolean(loadImageApiKey()) }))
ipcMain.handle('save-image-api-key', (_, value) => saveImageApiKey(value))
ipcMain.handle('get-window-bounds', () => {
  if (!mainWindow || mainWindow.isDestroyed()) return null
  return mainWindow.getBounds()
})
ipcMain.on('move-window', (_, position) => {
  if (!mainWindow || mainWindow.isDestroyed() || !position) return
  const x = Number(position.x)
  const y = Number(position.y)
  if (!Number.isFinite(x) || !Number.isFinite(y)) return
  const display = screen.getDisplayMatching(mainWindow.getBounds())
  const bounds = mainWindow.getBounds()
  const maxX = display.workArea.x + display.workArea.width - bounds.width
  const maxY = display.workArea.y + display.workArea.height - 40
  mainWindow.setPosition(
    Math.round(Math.max(display.workArea.x - bounds.width + 80, Math.min(x, maxX))),
    Math.round(Math.max(display.workArea.y, Math.min(y, maxY))),
    false
  )
})
ipcMain.handle('get-privacy', () => ({ enabled: screenPrivacyEnabled }))
ipcMain.handle('get-blur', () => ({ value: blurAmount }))
ipcMain.handle('set-blur', (_, value) => {
  blurAmount = Math.max(0, Math.min(60, Number(value) || 0))
  fs.mkdirSync(userDir, { recursive: true })
  fs.writeFileSync(blurPath, JSON.stringify({ value: blurAmount }), 'utf8')
  if (mainWindow && !mainWindow.isDestroyed()) {
    if (process.platform === 'win32' && typeof mainWindow.setBackgroundMaterial === 'function') {
      mainWindow.setBackgroundMaterial(blurAmount === 0 ? 'none' : 'acrylic')
    }
    mainWindow.webContents.send('blur-updated', blurAmount)
  }
  return { value: blurAmount }
})
ipcMain.handle('set-privacy', (_, enabled) => applyScreenPrivacy(enabled))
ipcMain.handle('resize-window', (_, size) => {
  if (!mainWindow || mainWindow.isDestroyed() || !size) return false
  const width = Math.max(560, Math.min(1600, Math.round(Number(size.width) || 900)))
  const height = Math.max(360, Math.min(1200, Math.round(Number(size.height) || 680)))
  const [currentWidth, currentHeight] = mainWindow.getSize()
  if (width === currentWidth && height === currentHeight) return true
  mainWindow.setSize(width, height, true)
  return true
})

ipcMain.handle('signin', async () => {
  const status = await signIn()
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('status-updated', status)
  }
  return status
})

ipcMain.handle('signout', () => {
  clearCredentials()
  const status = getStatus()
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('status-updated', status)
  }
  return status
})

ipcMain.handle('ask', async (event, payload) => {
  const result = await askAI(payload, progress => {
    if (!event.sender.isDestroyed()) event.sender.send('generation-progress', progress)
  })
  const history = readHistory()
  history.push({
    id: crypto.randomUUID(),
    time: new Date().toISOString(),
    prompt: String(payload.prompt || ''),
    answer: result.answer || (result.generatedImage ? 'Generated image' : ''),
    model: result.model,
    hasImage: Boolean(payload.imageData),
    generatedImage: Boolean(result.generatedImage)
  })
  writeHistory(history)
  return result
})

ipcMain.handle('save-image', async (_, dataUrl) => {
  if (typeof dataUrl !== 'string' || !/^data:image\/png;base64,/i.test(dataUrl)) {
    throw new Error('This image cannot be saved because its format is not supported.')
  }
  const result = await dialog.showSaveDialog(mainWindow, {
    title: 'Save generated image',
    defaultPath: 'Nebula-AI-Lunar-Image.png',
    filters: [{ name: 'PNG image', extensions: ['png'] }]
  })
  if (result.canceled || !result.filePath) return { canceled: true }
  const match = dataUrl.match(/^data:image\/png;base64,(.+)$/i)
  fs.writeFileSync(result.filePath, Buffer.from(match[1], 'base64'))
  return { canceled: false, filePath: result.filePath }
})

ipcMain.handle('capture', () => startCapture())
ipcMain.handle('capture-finished', (_, dataUrl) => {
  closeSelection()
  showMainWindow()
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('image-captured', dataUrl)
  }
  return true
})
ipcMain.handle('capture-cancel', () => {
  closeSelection()
  showMainWindow()
  return true
})
ipcMain.handle('get-history', () => readHistory())
ipcMain.handle('delete-history-item', (_, id) => {
  const items = readHistory().filter(item => item.id !== String(id))
  writeHistory(items)
  return items
})
ipcMain.handle('delete-all-history', () => {
  writeHistory([])
  return true
})
ipcMain.handle('open-usage', () => shell.openExternal('https://chatgpt.com/settings/usage'))
ipcMain.handle('set-expanded', (_, expanded) => {
  if (!mainWindow || mainWindow.isDestroyed()) return false
  const display = screen.getDisplayMatching(mainWindow.getBounds())
  const bounds = mainWindow.getBounds()
  const width = expanded ? Math.max(900, bounds.width) : 850
  const height = expanded ? Math.max(620, bounds.height) : 88
  const centerX = bounds.x + bounds.width / 2
  const x = Math.round(Math.max(display.workArea.x, Math.min(centerX - width / 2, display.workArea.x + display.workArea.width - width)))
  const y = Math.max(display.workArea.y + 12, Math.min(bounds.y, display.workArea.y + display.workArea.height - height))
  mainWindow.setBounds({ x, y, width, height }, true)
  mainWindow.setAlwaysOnTop(true, 'screen-saver')
  mainWindow.setContentProtection(screenPrivacyEnabled)
  return true
})
ipcMain.handle('hide-overlay', () => {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.hide()
  return true
})
ipcMain.handle('show-overlay', () => {
  showMainWindow()
  return true
})
ipcMain.handle('status', () => getStatus())
