# Nebula AI - Lunar 0.6.0

A Windows desktop assistant with support for attaching images, PDF files, and text/code documents to a prompt.

## Install
Run `Install-Nebula-AI-Lunar.cmd` on Windows. Node.js 22 or newer is required to build the installer.

## Attachments
Use the plus button next to the prompt to attach images, PDFs, and text/code files. Images are sent for visual analysis, PDFs are attached as document inputs, and text/code files are included as text. Files are limited to 12 MB each.

ChatGPT account access and image-generation API billing are separate.
