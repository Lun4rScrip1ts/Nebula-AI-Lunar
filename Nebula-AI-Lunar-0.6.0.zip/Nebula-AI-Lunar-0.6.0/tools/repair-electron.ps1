$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$packagePath = Join-Path $root 'node_modules\electron\package.json'
if (-not (Test-Path $packagePath)) {
  Write-Host 'Electron package is missing. npm install did not complete.' -ForegroundColor Red
  exit 1
}

$version = (Get-Content $packagePath -Raw | ConvertFrom-Json).version
$dist = Join-Path $root 'node_modules\electron\dist'
$exe = Join-Path $dist 'electron.exe'
if (Test-Path $exe) {
  Write-Host "Electron $version is ready."
  exit 0
}

$cache = Join-Path $env:LOCALAPPDATA 'electron\Cache'
$pattern = "electron-v$version-win32-x64.zip"
$zip = Get-ChildItem $cache -Recurse -File -Filter $pattern -ErrorAction SilentlyContinue |
  Sort-Object LastWriteTime -Descending |
  Select-Object -First 1 -ExpandProperty FullName

if (-not $zip) {
  Write-Host "Cached Electron archive was not found. Trying the official package installer..."
  & node (Join-Path $root 'node_modules\electron\install.js')
  $zip = Get-ChildItem $cache -Recurse -File -Filter $pattern -ErrorAction SilentlyContinue |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 1 -ExpandProperty FullName
}

if (-not $zip) {
  Write-Host "Electron's $pattern download was not found. Check internet access and rerun this installer." -ForegroundColor Red
  exit 1
}

$temp = Join-Path $env:TEMP "nebula-ai-lunar-electron-$version"
if (Test-Path $temp) { Remove-Item $temp -Recurse -Force }
New-Item -ItemType Directory -Force -Path $temp | Out-Null
Expand-Archive -LiteralPath $zip -DestinationPath $temp -Force

if (-not (Test-Path (Join-Path $temp 'electron.exe'))) {
  Write-Host "The cached archive did not contain electron.exe: $zip" -ForegroundColor Red
  exit 1
}

New-Item -ItemType Directory -Force -Path $dist | Out-Null
Copy-Item (Join-Path $temp '*') $dist -Recurse -Force
Set-Content -LiteralPath (Join-Path $root 'node_modules\electron\path.txt') -Value 'electron.exe' -NoNewline -Encoding ascii

if (-not (Test-Path $exe)) {
  Write-Host 'Electron extraction failed; electron.exe is still missing.' -ForegroundColor Red
  exit 1
}

Write-Host "Electron $version was prepared successfully." -ForegroundColor Green
exit 0
